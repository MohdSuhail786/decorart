import C from "./C";

export default function B() {

    return <>
        B
        <C />
    </>
}