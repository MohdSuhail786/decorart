export default {
    USER_ID: `user_jT9XEwk6QORKaNhCpi5q6`,
    TEMPLATE_ID: ``
}